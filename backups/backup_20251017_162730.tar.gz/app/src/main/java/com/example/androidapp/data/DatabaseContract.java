package com.example.androidapp.data;

public final class DatabaseContract {
    private DatabaseContract() {}

    public enum VoucherType {
        RECEIPT,
        PAYMENT
    }
}
